# SASREC_FEATURE_OPT_V1 — study state

Add-on study, lower priority than the running SASRec v3b campaign, which is never touched.
Package: `F:\Queens University\Microsoft Project\eda\SASREC_FEATURE_OPT_V1` (validate_package PASS).
Workspace: server `$R/.local_ai/feature_opt_v1/`, mirrored locally at `.local_ai\feature_opt_v1\`.
`.local_ai/` is already in `.git/info/exclude`.

## Status: AUDIT (read-only). GPU / heavy work = QUEUED_RESOURCE until the campaign's FINAL_STAGE_DONE

- [x] 2026-09-25T10:03Z workspace + source snapshot (evidence/snap: dataset docs + reuse code, byte copies)
- [x] 10:10Z protection snapshot T0 (state/PROTECT_T0_study_start.json): 185 active code/config/lock
      hashes, dataset metadata hashes + tree size, process identities, disk 12.37 GiB, cgroup mem 61.3/64 GiB
- [x] 10:15Z baseline rule registered (config/BASELINE_RULE.md), before any study score
- [x] 10:22Z Sonnet A inventory: FEATURE_INVENTORY.csv (69 rows), TRANSFORM_LINEAGE.json, FEATURE_DEPENDENCIES.json, REDUNDANCY_FINDINGS.md, OPEN_QUESTIONS.md, profiler (11 tests pass)
- [x] 10:25Z bounded sample profile (3/64 buckets, 1 core, peak 537 MiB) + 10:36Z duplicate/fit check -> audit/MEASURED_FINDINGS.md (M1 fit-population defect; 9 exact duplicates; 6 dead flags; drift)
- [x] 10:55Z Fable scope decision (owner-delegated): STAGED_WITH_EVIDENCE_GATES -> review/AUTO_DECISION_SCOPE.md (routing claude-fable-5-1 from transcript)
- [x] 11:05Z protocol + registry frozen (FEATURE_EXPERIMENT_PROTOCOL.md, config/candidate_registry.json; manifest sha 15cbb263… identical local/server)
- [x] study code (snapshot-isolated): fo_env, feature_view, fo_models, fo_eval, pin_baseline, stream_fit, probe_runner, screen, finalize_fo, fo_queue, protect_diff; smoke: lean fold parity 1.9e-7, D3 init exact
- [ ] Sonnet B independent tests -> Fable Review C -> review/FEATURE_CODE_REVIEW_PASS.json
- [ ] arm tmux fo-queue (waits for campaign FINAL_STAGE_DONE, GPU/disk gates) -> stream_fit, full profile, pin, probes + lean parity, screen CONTROL||C1_D3 (+C2), finalize
- [ ] FINAL_FEATURE_OPT_REPORT_AR.md (+ results JSON, SELECTED_FEATURES.json, TRANSFORM_STATE.json) — KEEP_CURRENT unless gate 2(b) yields a finalist

## Resource notes (measured, not historical)
- Disk free 12.37 GiB (10:10Z). A future full pair from scratch = 2 runs x (latest+previous with
  optimizer ~1.9 GiB + epoch weights ~0.33 GiB each) ≈ 5–7 GiB: must be budgeted against the 10 GiB target.
- RAM: two campaign trainers ~18 GB RSS each; study audit processes must stay tiny while they run.
- Compute cost of this study is recorded separately from the campaign ETA.
