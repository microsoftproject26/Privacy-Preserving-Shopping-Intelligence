# FABLE_CODE_REVIEW — Review C, pass 1 (owner-delegated), 2026-09-25

- **Runtime routing** (from the transcript): ['claude-fable-5-1']
- **Agent:** sasrec-fable-reviewer (Read/Grep/Glob only)
- **Brief:** review/REVIEW_C_BRIEF.md
- **Reviewed hashes:** review/REVIEW_C_HASHES.json

## Verbatim

ROUTING: claude-fable-5-1
VERDICT: FIX_REQUIRED

FINDINGS:
- HIGH `code\finalize_fo.py:91-114,117` — TRANSFORM_STATE/SELECTED_FEATURES assert "reproduce the incumbent's predictions to float rounding" unconditionally: no threshold on LEAN_PARITY (`max_abs_logit_diff`, `ranks_identical_fraction`), and `lean=None` (LEAN_PARITY.json absent) still writes the claim [evidence]. Also nothing gates the fold's assumed relations: `audit/DUPLICATES_FULL.json` mismatch counts and `local_hour_rotation_max_residual` are never read [evidence]. Fix: require LEAN_PARITY.json; write the hygiene deliverable only if all DUPLICATES_FULL counts are 0, rotation residual ≤ 1e-6, max|Δlogit| ≤ 1e-3 and rank-identical ≥ 0.999 (thresholds [inference]); otherwise emit `PARITY_FAILED`, no equivalence claim.
- HIGH `code\probe_runner.py:54-57,81` — `check()` passes vacuously when `n == 0`; `ok = not bad` ignores counts. The protocol's "every injected encoding is compared with real rows; any mismatch aborts" is not met if the cohort has no row in a state (e.g. `cur_price_missing_supported`) [evidence]. Fix: `ok` requires every count > 0 (floor ≥ 100 [inference]); otherwise abort with `UNVERIFIED_ENCODING`.
- MEDIUM `code\screen.py:97` — `label_smoothing=0.0` hard-coded; the campaign uses `entry["label_smoothing"]` (`snap_sasrec\train_sasrec.py:391,697`) [evidence]. Fix: assert `float(ch["registry_entry"]["label_smoothing"]) == 0.0` before training.
- MEDIUM `code\fo_queue.py:64-74,84` — `gpu_busy` fails open: a compute app whose bus id is not in the `--query-gpu` map is keyed under the raw id and never matches `str(g)`; an `nvidia-smi` failure yields "free" [evidence]. Fix: non-zero rc or any unmapped app → all GPUs busy.
- MEDIUM `code\probe_runner.py:90-92,109` — retry hazard: attempt 2 hits `FileExistsError` on `PROBE_ENCODING_CHECK.json`; if the run dies after `GROUP_PROBE_RESULTS.json` is written, the early return skips lean parity forever and finalize silently proceeds with `lean=None` [evidence]. Fix: skip the encoding write if present; run the lean-parity block whenever LEAN_PARITY.json is missing.
- MEDIUM tests — no test of `finalize_fo` gate 2(b) (threshold, CI, R@20 guard, single finalist) with fabricated results and negative controls [evidence: no `test_fo_finalize*.py` in `code\tests`].
- LOW `code\fo_env.py:51` — `assert_isolated` uses the same string-prefix idiom that was a defect in `study_path`; harmless today (live path is not a prefix) [inference]; use `is_relative_to`.
- LOW `code\feature_view.py:299-301` — the affine shift is inferred from clip bounds, never cross-checked against the measured shifts (`stream_fit.AFFINE` 0.0/1.0) [evidence]; add the assertion.

CHECKS:
- active paths never written: PASS [evidence] — all writes go through `study_path` / `F/`; snapshot `paths.py:19-20,39-41` puts snapshot `reuse`/`vendor` on sys.path; campaign root `S` is unused by the study; dataset read-only.
- TRAIN-only fit: PASS [evidence] — `stream_fit.py:74-80` fits TRAIN valid rows with recorded clips; VS drift-only; D3 no fit; manifest from TRAIN; P8 cell TRAIN-modal.
- no future information: PASS [evidence] — `d3_features` `tril(-1)`/cumsum causal, tested (`test_d3_future_never_changes_past`); probes touch context only; P4 uses `lengths-1`.
- no unqualified OOV identity comparison: PASS [evidence] — `known = real & tok>=3` on both sides of `eq` (`feature_view.py:348-351,359`), tested.
- no structural-mask ablation: PASS [evidence] — `attention_mask`/`lengths` never modified; P1 toggles `side_enabled` only, labelled OOD.
- no absent value made to look known: PASS [evidence] — every probe sets the flag/mask with the loader's re-zero value; M1 repair keeps mask 0 with 0.0. Caveat: the HIGH encoding-check vacuity above.
- no double log/scale: PASS [evidence] — `enc_event` clips+z once on raw; sin/cos unscaled; M1 inverse `x*old_std+old_mean` stays in log1p space (`to_lean`, tested).
- matched control/exposure/schedule: PASS [evidence] — same pinned weights, fresh AdamW, same manifest (sha checked at full scale), `lr_at` warmup/cosine, `train_arm` mirrors `train_step` (loss_mask, n_total, clip, set_lr, step, recenter); seed 2026 after build. Caveat: smoothing assertion (MEDIUM).
- checkpoint mapping strict: PASS [evidence] — `strict=True`, `_resize_inputs` then load, `parameter_mapping`, refusal test.
- single-decision CE: PASS [evidence] — `ce_sum` with `loss_mask`, one-target check.
- exact evaluation: PASS [evidence] — snapshot `evaluate_model` under `strict_eval`, exhaustive K, OOV zero credit in denominator (tested); VS-only store either yields identical windows or raises (`full_store.py:260`).
- warm-start labelled exploratory / pair from scratch: PASS [evidence] — labels in `screen.py:173`, registry `pair.otherwise`; pair not implemented.

CHOICES:
1. M1 refit: CONFIRM. Recorded clips kept → affine on available rows; fold `a·x' + (c−z0)·mask + z0` is algebraically exact (`feature_view.py:320-327`) [evidence]. Report, do not apply, valid-only quantiles.
2. Probe positions: CONFIRM all three. P4 last-event only with `current_minus_recent` via the supported rule; P5/P6 at every real position; P2 leaves `category_tokens` (MISSING row untrained) [evidence].
3. Gate 2(a) excludes P1: CONFIRM (`probe_runner.py:141`).
4. C1_D3: CONFIRM. Columns 19-23 zero-init, `_side_residual` concat order matches `d3_state_dict`; fold and D3 independent; ratio denominator `t+1` incl. OOV is bounded and causal — record this definition in the registry text [inference].
5. C2 as permanent adapter in train+eval: CONFIRM (`FOModel.forward`, `build_arm`).
6. Screen on the training store, VS cohort-only: CONFIRM (`build_training_store`, TRAIN loss decisions).
7. Pair not implemented: CONFIRM; correction-only review required before any pair training.
8. fo_queue: CONFIRM the rules as written, subject to the fail-closed GPU fix. Pass file must be written only after the fixed files are re-hashed.

APPROVED_HASHES: not approved as a set. Files that must change: `code/finalize_fo.py`, `code/probe_runner.py`, `code/screen.py`, `code/fo_queue.py` (plus optional `code/fo_env.py`, `code/feature_view.py` low items, and a new `code/tests/test_fo_finalize.py`). All other entries in `F:\Queens University\Microsoft Project\eda\.local_ai\feature_opt_v1\review\REVIEW_C_HASHES.json` are acceptable as listed; re-submit the changed files' hashes for a correction-only check before `FEATURE_CODE_REVIEW_PASS.json` is written.
