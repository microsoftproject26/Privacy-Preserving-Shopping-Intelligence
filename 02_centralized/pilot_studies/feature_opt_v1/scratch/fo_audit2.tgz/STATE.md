# SASREC_FEATURE_OPT_V1 — study state

Add-on study, lower priority than the running SASRec v3b campaign, which is never touched.
Package: `F:\Queens University\Microsoft Project\eda\SASREC_FEATURE_OPT_V1` (validate_package PASS).
Workspace: server `$R/.local_ai/feature_opt_v1/`, mirrored locally at `.local_ai\feature_opt_v1\`.
`.local_ai/` is already in `.git/info/exclude`.

## Status: AUDIT (read-only). GPU / heavy work = QUEUED_RESOURCE until the campaign's FINAL_STAGE_DONE

- [x] 2026-09-25T10:03Z workspace + source snapshot (evidence/snap: dataset docs + reuse code, byte copies)
- [x] 10:10Z protection snapshot T0 (state/PROTECT_T0_study_start.json): 185 active code/config/lock
      hashes, dataset metadata hashes + tree size, process identities, disk 12.37 GiB, cgroup mem 61.3/64 GiB
- [x] 10:15Z baseline rule registered (config/BASELINE_RULE.md), before any study score
- [ ] Sonnet A: FEATURE_INVENTORY.csv, TRANSFORM_LINEAGE.json, FEATURE_DEPENDENCIES.json, redundancy, open questions, bounded profiler
- [ ] bounded TRAIN/VS sample profile (1 thread, <=400 MiB) — allowed now
- [ ] probe protocol (baseline + <=8 coherent group probes) frozen before scoring
- [ ] QUEUED_RESOURCE: full streamed TRAIN profile + probes after campaign FINAL_STAGE_DONE (~2026-09-26T07:30Z)
- [ ] Fable Review P -> FEATURE_EXPERIMENT_PROTOCOL.md + candidate_registry.json
- [ ] implementation + Sonnet B independent tests -> Fable Review C
- [ ] screen (<=6 GPU-h) -> <=1 finalist -> full-TRAIN matched pair (5 epochs, from scratch)
- [ ] FINAL_FEATURE_OPT_REPORT_AR.md + FINAL_FEATURE_OPT_RESULTS.json + SELECTED_FEATURES.json/TRANSFORM_STATE.json or KEEP_CURRENT

## Resource notes (measured, not historical)
- Disk free 12.37 GiB (10:10Z). A future full pair from scratch = 2 runs x (latest+previous with
  optimizer ~1.9 GiB + epoch weights ~0.33 GiB each) ≈ 5–7 GiB: must be budgeted against the 10 GiB target.
- RAM: two campaign trainers ~18 GB RSS each; study audit processes must stay tiny while they run.
- Compute cost of this study is recorded separately from the campaign ETA.
